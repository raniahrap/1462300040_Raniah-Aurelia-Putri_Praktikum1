package com.example.flutter_aktivitas1

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
