import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_application_2/main.dart';

void main() {
  testWidgets('Welcome page tampil saat aplikasi dibuka', (WidgetTester tester) async {
    await tester.pumpWidget(const MyApp());

    expect(find.text('Welcome to'), findsOneWidget);
    expect(find.text('PRAKTIKUM PAB 2023'), findsOneWidget);
    expect(find.text('Raniah Aurelia Putri'), findsOneWidget);
    expect(find.text('Masuk'), findsOneWidget);
  });
}
