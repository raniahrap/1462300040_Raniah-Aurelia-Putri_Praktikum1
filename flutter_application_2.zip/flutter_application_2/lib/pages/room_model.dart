class Room {
  final String name;
  final String price;
  final String description;
  final String imageUrl;

  const Room({
    required this.name,
    required this.price,
    required this.description,
    required this.imageUrl,
  });
}

const List<Room> daftarKamar = [
  Room(
    name: 'Suite Room',
    price: '\$100 / night',
    description:
        'Enjoy luxury rooms with beautiful views and comfortable atmosphere.',
    imageUrl:
        'https://images.unsplash.com/photo-1631049307264-da0ec9d70304?auto=format&fit=crop&w=600&q=80',
  ),
  Room(
    name: 'Villa Room',
    price: '\$120 / night',
    description:
        'Enjoy luxury rooms with beautiful views and comfortable atmosphere.',
    imageUrl:
        'https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?auto=format&fit=crop&w=600&q=80',
  ),
  Room(
    name: 'Villa 2 Room',
    price: '\$150 / night',
    description:
        'Villa 2 lantai dengan kolam renang pribadi dan area santai yang luas.',
    imageUrl:
        'https://images.unsplash.com/photo-1571003123894-1f0594d2b5d9?auto=format&fit=crop&w=600&q=80',
  ),
  Room(
    name: 'Villa 3 Room',
    price: '\$180 / night',
    description:
        'Villa 3 kamar tidur, cocok untuk keluarga besar dengan fasilitas lengkap.',
    imageUrl:
        'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=600&q=80',
  ),
];
